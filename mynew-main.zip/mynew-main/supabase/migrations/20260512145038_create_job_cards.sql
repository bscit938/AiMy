/*
  # Mobile Service Center - Job Cards Schema

  1. New Tables
    - `job_cards`
      - `id` (uuid, primary key)
      - `job_no` (text, unique, auto-incremented job receipt number)
      - `date` (date)
      - `time` (time)
      - `mobile_no` (text, customer phone number)
      - `brand` (text, phone brand)
      - `model` (text, phone model)
      - `imei_no` (text)
      - `password` (text, device unlock password)
      - `has_battery` (boolean)
      - `has_back_door` (boolean)
      - `box_no` (text)
      - `others` (text)
      - `fault` (text, reported fault/complaint)
      - `estimate` (numeric)
      - `advance` (numeric)
      - `status` (text: pending, in_progress, completed, delivered)
      - `technician_name` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `job_cards` table
    - Add policies for authenticated users to manage their data
*/

CREATE TABLE IF NOT EXISTS job_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_no text UNIQUE NOT NULL,
  date date NOT NULL DEFAULT CURRENT_DATE,
  time time NOT NULL DEFAULT CURRENT_TIME,
  mobile_no text NOT NULL DEFAULT '',
  brand text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  imei_no text NOT NULL DEFAULT '',
  password text NOT NULL DEFAULT '',
  has_battery boolean NOT NULL DEFAULT false,
  has_back_door boolean NOT NULL DEFAULT false,
  box_no text NOT NULL DEFAULT '',
  others text NOT NULL DEFAULT '',
  fault text NOT NULL DEFAULT '',
  estimate numeric(10,2) NOT NULL DEFAULT 0,
  advance numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  technician_name text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE job_cards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can select job cards"
  ON job_cards FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert job cards"
  ON job_cards FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update job cards"
  ON job_cards FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete job cards"
  ON job_cards FOR DELETE
  TO authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_job_cards_date ON job_cards(date DESC);
CREATE INDEX IF NOT EXISTS idx_job_cards_status ON job_cards(status);
CREATE INDEX IF NOT EXISTS idx_job_cards_mobile_no ON job_cards(mobile_no);

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER job_cards_updated_at
  BEFORE UPDATE ON job_cards
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE SEQUENCE IF NOT EXISTS job_card_seq START 1000;
