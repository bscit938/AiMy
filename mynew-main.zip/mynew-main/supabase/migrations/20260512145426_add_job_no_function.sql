/*
  # Add generate_job_no function

  Creates a function that returns the next job card number from the sequence,
  formatted as a zero-padded 4-digit string.
*/

CREATE OR REPLACE FUNCTION generate_job_no()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  next_val bigint;
BEGIN
  next_val := nextval('job_card_seq');
  RETURN LPAD(next_val::text, 4, '0');
END;
$$;
