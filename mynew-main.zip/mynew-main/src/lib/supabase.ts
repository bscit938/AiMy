import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type JobCardStatus = 'pending' | 'in_progress' | 'completed' | 'delivered';

export interface JobCard {
  id: string;
  job_no: string;
  date: string;
  time: string;
  mobile_no: string;
  brand: string;
  model: string;
  imei_no: string;
  password: string;
  has_battery: boolean;
  has_back_door: boolean;
  box_no: string;
  others: string;
  fault: string;
  estimate: number;
  advance: number;
  status: JobCardStatus;
  technician_name: string;
  created_at: string;
  updated_at: string;
}

export type JobCardInsert = Omit<JobCard, 'id' | 'created_at' | 'updated_at'>;
