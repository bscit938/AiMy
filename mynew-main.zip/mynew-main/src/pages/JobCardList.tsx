import { useEffect, useState } from 'react';
import { Search, Plus, Eye, Edit2, Printer, ChevronDown, Filter, Loader } from 'lucide-react';
import { supabase, JobCard } from '../lib/supabase';

interface JobCardListProps {
  onNew: () => void;
  onEdit: (job: JobCard) => void;
  onPrint: (job: JobCard) => void;
  onView: (job: JobCard) => void;
}

const statusConfig = {
  pending: { label: 'Pending', cls: 'bg-amber-100 text-amber-700' },
  in_progress: { label: 'In Progress', cls: 'bg-blue-100 text-blue-700' },
  completed: { label: 'Completed', cls: 'bg-green-100 text-green-700' },
  delivered: { label: 'Delivered', cls: 'bg-gray-100 text-gray-600' },
};

export default function JobCardList({ onNew, onEdit, onPrint, onView }: JobCardListProps) {
  const [jobs, setJobs] = useState<JobCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showFilter, setShowFilter] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, [statusFilter]);

  async function fetchJobs() {
    setLoading(true);
    let q = supabase.from('job_cards').select('*').order('created_at', { ascending: false });
    if (statusFilter !== 'all') q = q.eq('status', statusFilter);
    const { data } = await q;
    setJobs((data as JobCard[]) || []);
    setLoading(false);
  }

  async function updateStatus(id: string, status: string) {
    await supabase.from('job_cards').update({ status }).eq('id', id);
    fetchJobs();
  }

  const filtered = jobs.filter((j) => {
    const q = search.toLowerCase();
    return !q || j.job_no.includes(q) || j.mobile_no.includes(q) || j.brand.toLowerCase().includes(q) || j.model.toLowerCase().includes(q);
  });

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Job Cards</h1>
          <p className="text-sm text-gray-500 mt-1">{filtered.length} records</p>
        </div>
        <button
          onClick={onNew}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2.5 rounded-xl font-semibold text-sm shadow-sm transition-colors"
        >
          <Plus size={16} />
          New Job
        </button>
      </div>

      <div className="flex gap-3 mb-5">
        <div className="flex-1 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search by job no, mobile, brand..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
          />
        </div>
        <div className="relative">
          <button
            onClick={() => setShowFilter(!showFilter)}
            className="flex items-center gap-2 border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 bg-white font-medium"
          >
            <Filter size={14} />
            {statusFilter === 'all' ? 'All Status' : statusConfig[statusFilter as keyof typeof statusConfig]?.label}
            <ChevronDown size={14} />
          </button>
          {showFilter && (
            <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-xl shadow-lg z-20 min-w-[160px] py-1">
              {['all', 'pending', 'in_progress', 'completed', 'delivered'].map((s) => (
                <button
                  key={s}
                  onClick={() => { setStatusFilter(s); setShowFilter(false); }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${statusFilter === s ? 'text-green-600 font-semibold' : 'text-gray-700'}`}
                >
                  {s === 'all' ? 'All Status' : statusConfig[s as keyof typeof statusConfig]?.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader size={24} className="animate-spin text-green-500" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <Search size={40} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">No job cards found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((job) => (
            <JobRow key={job.id} job={job} onEdit={onEdit} onPrint={onPrint} onView={onView} onStatusChange={updateStatus} />
          ))}
        </div>
      )}
    </div>
  );
}

function JobRow({ job, onEdit, onPrint, onView, onStatusChange }: {
  job: JobCard;
  onEdit: (j: JobCard) => void;
  onPrint: (j: JobCard) => void;
  onView: (j: JobCard) => void;
  onStatusChange: (id: string, status: string) => void;
}) {
  const [showStatus, setShowStatus] = useState(false);
  const cfg = statusConfig[job.status] || statusConfig.pending;

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-gray-900">#{job.job_no}</span>
            <div className="relative">
              <button
                onClick={() => setShowStatus(!showStatus)}
                className={`text-xs px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 ${cfg.cls}`}
              >
                {cfg.label}
                <ChevronDown size={10} />
              </button>
              {showStatus && (
                <div className="absolute left-0 top-full mt-1 bg-white border border-gray-200 rounded-xl shadow-lg z-20 min-w-[140px] py-1">
                  {Object.entries(statusConfig).map(([s, c]) => (
                    <button
                      key={s}
                      onClick={() => { onStatusChange(job.id, s); setShowStatus(false); }}
                      className={`w-full text-left px-3 py-1.5 text-xs hover:bg-gray-50 ${s === job.status ? 'font-bold' : ''}`}
                    >{c.label}</button>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="text-sm text-gray-700 mt-1 font-medium">{job.brand} {job.model}</div>
          <div className="text-xs text-gray-400 mt-0.5 flex gap-3 flex-wrap">
            <span>{job.mobile_no}</span>
            {job.imei_no && <span>IMEI: {job.imei_no}</span>}
            <span>{new Date(job.date).toLocaleDateString('en-IN')}</span>
          </div>
          {job.fault && (
            <div className="text-xs text-gray-500 mt-1.5 bg-gray-50 rounded-lg px-2 py-1 truncate">{job.fault}</div>
          )}
        </div>
        <div className="text-right flex-shrink-0">
          <div className="text-base font-bold text-gray-900">₹{Number(job.estimate).toLocaleString('en-IN')}</div>
          {job.advance > 0 && <div className="text-xs text-green-600 font-medium">Adv: ₹{Number(job.advance).toLocaleString('en-IN')}</div>}
          <div className="flex gap-1.5 mt-2 justify-end">
            <IconBtn onClick={() => onView(job)} title="View"><Eye size={15} /></IconBtn>
            <IconBtn onClick={() => onEdit(job)} title="Edit"><Edit2 size={15} /></IconBtn>
            <IconBtn onClick={() => onPrint(job)} title="Print" highlight><Printer size={15} /></IconBtn>
          </div>
        </div>
      </div>
    </div>
  );
}

function IconBtn({ onClick, children, title, highlight }: { onClick: () => void; children: React.ReactNode; title?: string; highlight?: boolean }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={`p-1.5 rounded-lg transition-colors ${highlight ? 'bg-green-50 text-green-600 hover:bg-green-100' : 'text-gray-400 hover:text-gray-700 hover:bg-gray-100'}`}
    >{children}</button>
  );
}
