import { useState } from 'react';
import { ArrowLeft, Save, Printer } from 'lucide-react';
import { supabase, JobCard, JobCardInsert } from '../lib/supabase';

interface JobCardFormProps {
  onBack: () => void;
  onSaved: (job: JobCard) => void;
  editJob?: JobCard | null;
}

export default function JobCardForm({ onBack, onSaved, editJob }: JobCardFormProps) {
  const today = new Date().toISOString().split('T')[0];
  const nowTime = new Date().toTimeString().slice(0, 5);

  const [form, setForm] = useState<Omit<JobCardInsert, 'job_no'>>({
    date: editJob?.date ?? today,
    time: editJob?.time ?? nowTime,
    mobile_no: editJob?.mobile_no ?? '',
    brand: editJob?.brand ?? '',
    model: editJob?.model ?? '',
    imei_no: editJob?.imei_no ?? '',
    password: editJob?.password ?? '',
    has_battery: editJob?.has_battery ?? false,
    has_back_door: editJob?.has_back_door ?? false,
    box_no: editJob?.box_no ?? '',
    others: editJob?.others ?? '',
    fault: editJob?.fault ?? '',
    estimate: editJob?.estimate ?? 0,
    advance: editJob?.advance ?? 0,
    status: editJob?.status ?? 'pending',
    technician_name: editJob?.technician_name ?? '',
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  function set(field: string, value: string | boolean | number) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.mobile_no.trim()) { setError('Customer mobile number is required.'); return; }
    if (!form.brand.trim()) { setError('Brand is required.'); return; }
    setError('');
    setSaving(true);

    if (editJob) {
      const { data, error: err } = await supabase
        .from('job_cards')
        .update(form)
        .eq('id', editJob.id)
        .select()
        .single();
      if (err) { setError(err.message); setSaving(false); return; }
      onSaved(data as JobCard);
    } else {
      const { data: seqData } = await supabase.rpc('generate_job_no').maybeSingle();
      const jobNo = seqData ? String(seqData) : `J${Date.now()}`;
      const { data, error: err } = await supabase
        .from('job_cards')
        .insert({ ...form, job_no: jobNo })
        .select()
        .single();
      if (err) { setError(err.message); setSaving(false); return; }
      onSaved(data as JobCard);
    }
    setSaving(false);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3 sticky top-0 z-10 shadow-sm">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
          <ArrowLeft size={20} className="text-gray-600" />
        </button>
        <div>
          <h2 className="font-bold text-gray-900">{editJob ? `Edit Job #${editJob.job_no}` : 'New Job Card'}</h2>
          <p className="text-xs text-gray-400">Mobile Service Center</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-2xl mx-auto p-4 md:p-8 space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-3 text-sm">{error}</div>
        )}

        <Section title="Job Details">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Date" required>
              <input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} className={inputCls} required />
            </Field>
            <Field label="Time" required>
              <input type="time" value={form.time} onChange={(e) => set('time', e.target.value)} className={inputCls} required />
            </Field>
          </div>
          <Field label="Status">
            <select value={form.status} onChange={(e) => set('status', e.target.value)} className={inputCls}>
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="delivered">Delivered</option>
            </select>
          </Field>
        </Section>

        <Section title="Customer & Device">
          <Field label="Customer Mobile No." required>
            <input
              type="tel" placeholder="e.g. 9750862713"
              value={form.mobile_no} onChange={(e) => set('mobile_no', e.target.value)}
              className={inputCls} required
            />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Brand" required>
              <input placeholder="e.g. vivo, Samsung" value={form.brand} onChange={(e) => set('brand', e.target.value)} className={inputCls} required />
            </Field>
            <Field label="Model">
              <input placeholder="e.g. Y56" value={form.model} onChange={(e) => set('model', e.target.value)} className={inputCls} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="IMEI No.">
              <input placeholder="15-digit IMEI" value={form.imei_no} onChange={(e) => set('imei_no', e.target.value)} className={inputCls} />
            </Field>
            <Field label="Device Password">
              <input placeholder="Unlock password / PIN" value={form.password} onChange={(e) => set('password', e.target.value)} className={inputCls} />
            </Field>
          </div>
        </Section>

        <Section title="Accessories Particulars">
          <div className="grid grid-cols-3 gap-4">
            <CheckboxField label="Battery" checked={form.has_battery} onChange={(v) => set('has_battery', v)} />
            <CheckboxField label="Back Door" checked={form.has_back_door} onChange={(v) => set('has_back_door', v)} />
            <Field label="Box No.">
              <input placeholder="BOX No." value={form.box_no} onChange={(e) => set('box_no', e.target.value)} className={inputCls} />
            </Field>
          </div>
          <Field label="Others">
            <input placeholder="Other accessories" value={form.others} onChange={(e) => set('others', e.target.value)} className={inputCls} />
          </Field>
        </Section>

        <Section title="Fault & Billing">
          <Field label="Fault / Complaint" required>
            <textarea
              placeholder="Describe the issue (e.g. Auto ON/OFF, Charging problem...)"
              value={form.fault} onChange={(e) => set('fault', e.target.value)}
              className={`${inputCls} resize-none`} rows={3}
            />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Estimate (₹)">
              <input
                type="number" min="0" step="0.01" placeholder="0.00"
                value={form.estimate || ''} onChange={(e) => set('estimate', parseFloat(e.target.value) || 0)}
                className={inputCls}
              />
            </Field>
            <Field label="Advance (₹)">
              <input
                type="number" min="0" step="0.01" placeholder="0.00"
                value={form.advance || ''} onChange={(e) => set('advance', parseFloat(e.target.value) || 0)}
                className={inputCls}
              />
            </Field>
          </div>
          <Field label="Technician Name">
            <input placeholder="Technician handling this job" value={form.technician_name} onChange={(e) => set('technician_name', e.target.value)} className={inputCls} />
          </Field>
        </Section>

        <div className="flex gap-3 pb-8">
          <button type="submit" disabled={saving} className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white py-3 rounded-xl font-semibold transition-colors shadow-sm">
            <Save size={18} />
            {saving ? 'Saving...' : editJob ? 'Update Job Card' : 'Create Job Card'}
          </button>
          <button type="button" onClick={onBack} className="px-5 py-3 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 font-medium transition-colors">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

const inputCls = 'w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white placeholder:text-gray-400 transition';

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm space-y-4">
      <h3 className="font-semibold text-gray-700 text-sm uppercase tracking-wide border-b border-gray-100 pb-2">{title}</h3>
      {children}
    </div>
  );
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
        {label}{required && <span className="text-red-400 ml-0.5">*</span>}
      </label>
      {children}
    </div>
  );
}

function CheckboxField({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">{label}</label>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => onChange(true)}
          className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-colors ${checked ? 'bg-green-600 text-white border-green-600' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
        >Yes</button>
        <button
          type="button"
          onClick={() => onChange(false)}
          className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-colors ${!checked ? 'bg-red-500 text-white border-red-500' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
        >No</button>
      </div>
    </div>
  );
}
