import { ArrowLeft, Edit2, Printer, CheckCircle, XCircle, Clock, Wrench, PackageCheck, Truck } from 'lucide-react';
import { JobCard } from '../lib/supabase';

interface JobCardViewProps {
  job: JobCard;
  onBack: () => void;
  onEdit: (job: JobCard) => void;
  onPrint: (job: JobCard) => void;
}

const statusSteps = ['pending', 'in_progress', 'completed', 'delivered'] as const;
const statusIcons = { pending: Clock, in_progress: Wrench, completed: PackageCheck, delivered: Truck };
const statusLabels = { pending: 'Received', in_progress: 'In Progress', completed: 'Repaired', delivered: 'Delivered' };

export default function JobCardView({ job, onBack, onEdit, onPrint }: JobCardViewProps) {
  const currentStep = statusSteps.indexOf(job.status);
  const balance = Number(job.estimate) - Number(job.advance);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3 sticky top-0 z-10 shadow-sm">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
          <ArrowLeft size={20} className="text-gray-600" />
        </button>
        <div className="flex-1">
          <h2 className="font-bold text-gray-900">Job #{job.job_no}</h2>
          <p className="text-xs text-gray-400">{job.brand} {job.model}</p>
        </div>
        <button onClick={() => onEdit(job)} className="p-2 rounded-xl hover:bg-gray-100 text-gray-500 transition-colors">
          <Edit2 size={18} />
        </button>
        <button onClick={() => onPrint(job)} className="flex items-center gap-1.5 bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-xl text-sm font-semibold transition-colors">
          <Printer size={15} />
          Print
        </button>
      </div>

      <div className="max-w-2xl mx-auto p-4 md:p-8 space-y-5">
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-4">Repair Status</p>
          <div className="flex items-center">
            {statusSteps.map((step, i) => {
              const Icon = statusIcons[step];
              const done = i <= currentStep;
              return (
                <div key={step} className="flex items-center flex-1">
                  <div className="flex flex-col items-center">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${done ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-400'}`}>
                      <Icon size={16} />
                    </div>
                    <span className={`text-xs mt-1 font-medium text-center ${done ? 'text-green-700' : 'text-gray-400'}`} style={{ maxWidth: 60 }}>{statusLabels[step]}</span>
                  </div>
                  {i < statusSteps.length - 1 && (
                    <div className={`flex-1 h-1 mx-1 rounded-full transition-colors ${i < currentStep ? 'bg-green-500' : 'bg-gray-200'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-3">Customer & Device</p>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <Detail label="Customer Mobile" value={job.mobile_no} />
            <Detail label="Date" value={new Date(job.date).toLocaleDateString('en-IN')} />
            <Detail label="Brand" value={job.brand} />
            <Detail label="Model" value={job.model || '—'} />
            <Detail label="IMEI No." value={job.imei_no || '—'} />
            <Detail label="Password" value={job.password || '—'} />
            {job.technician_name && <Detail label="Technician" value={job.technician_name} />}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-3">Accessories</p>
          <div className="grid grid-cols-3 gap-3 text-sm">
            <AccessItem label="Battery" value={job.has_battery} />
            <AccessItem label="Back Door" value={job.has_back_door} />
            <Detail label="Box No." value={job.box_no || '—'} />
          </div>
          {job.others && <Detail label="Others" value={job.others} />}
        </div>

        {job.fault && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
            <p className="text-xs text-amber-600 font-semibold uppercase tracking-wide mb-1">Fault / Complaint</p>
            <p className="text-gray-800">{job.fault}</p>
          </div>
        )}

        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-3">Billing</p>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Estimate</span>
              <span className="font-bold text-gray-900">₹{Number(job.estimate).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Advance Paid</span>
              <span className="font-semibold text-green-600">₹{Number(job.advance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between text-base font-bold border-t border-gray-100 pt-2 mt-1">
              <span className="text-gray-700">Balance Due</span>
              <span className={balance > 0 ? 'text-red-600' : 'text-green-600'}>
                ₹{Math.abs(balance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                {balance <= 0 && ' (Paid)'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <p className="font-semibold text-gray-800">{value}</p>
    </div>
  );
}

function AccessItem({ label, value }: { label: string; value: boolean }) {
  return (
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <div className="flex items-center gap-1 mt-0.5">
        {value
          ? <><CheckCircle size={14} className="text-green-500" /><span className="text-sm font-semibold text-green-700">Yes</span></>
          : <><XCircle size={14} className="text-red-400" /><span className="text-sm font-semibold text-red-500">No</span></>
        }
      </div>
    </div>
  );
}
