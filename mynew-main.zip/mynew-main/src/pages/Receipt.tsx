import { Printer, ArrowLeft, CheckCircle, XCircle } from 'lucide-react';
import { JobCard } from '../lib/supabase';

interface ReceiptProps {
  job: JobCard;
  onBack: () => void;
}

export default function Receipt({ job, onBack }: ReceiptProps) {
  function handlePrint() {
    window.print();
  }

  const balance = Number(job.estimate) - Number(job.advance);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-white border-b border-gray-200 px-4 py-4 flex items-center gap-3 print:hidden sticky top-0 z-10 shadow-sm">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
          <ArrowLeft size={20} className="text-gray-600" />
        </button>
        <div className="flex-1">
          <h2 className="font-bold text-gray-900">Job Receipt #{job.job_no}</h2>
        </div>
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl font-semibold text-sm shadow-sm transition-colors"
        >
          <Printer size={16} />
          Print
        </button>
      </div>

      <div className="max-w-2xl mx-auto p-4 md:p-8">
        <div id="receipt" className="bg-white rounded-2xl shadow-sm overflow-hidden print:shadow-none print:rounded-none">
          <div className="bg-green-700 text-white p-6 text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <span className="font-black text-lg">M</span>
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight">Mobile Care</h1>
                <p className="text-green-200 text-xs font-medium">Multi Brand Service Centre</p>
              </div>
            </div>
            <p className="text-green-200 text-xs mt-2">NRT Complex, Ankalamman Kovil Opposite, PALLADAM - 641 664.</p>
            <p className="text-green-100 text-xs font-medium">Mobile: 9095 007 007 (WhatsApp)</p>
          </div>

          <div className="p-6">
            <div className="flex items-center justify-between mb-6 border-b border-dashed border-green-300 pb-4">
              <div>
                <div className="text-xs text-gray-500 uppercase tracking-widest font-bold">Job Receipt</div>
                <div className="text-2xl font-black text-green-700">#{job.job_no}</div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold text-gray-700">
                  {new Date(job.date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                </div>
                <div className="text-sm text-gray-500">{job.time}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-5 text-sm">
              <InfoRow label="Customer Mobile" value={job.mobile_no} />
              <InfoRow label="Brand" value={job.brand} />
              <InfoRow label="Model" value={job.model || '—'} />
              <InfoRow label="IMEI No." value={job.imei_no || '—'} />
              <InfoRow label="Device Password" value={job.password || '—'} />
              {job.technician_name && <InfoRow label="Technician" value={job.technician_name} />}
            </div>

            <div className="bg-gray-50 rounded-xl p-4 mb-5">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Accessories Particulars</p>
              <div className="grid grid-cols-3 gap-3 text-sm">
                <AccessoryItem label="Battery" value={job.has_battery} />
                <AccessoryItem label="Back Door" value={job.has_back_door} />
                <div>
                  <p className="text-xs text-gray-500">Box No.</p>
                  <p className="font-semibold text-gray-800">{job.box_no || '—'}</p>
                </div>
              </div>
              {job.others && (
                <div className="mt-2">
                  <p className="text-xs text-gray-500">Others</p>
                  <p className="text-sm text-gray-700">{job.others}</p>
                </div>
              )}
            </div>

            {job.fault && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-5">
                <p className="text-xs font-bold text-amber-600 uppercase tracking-wide mb-1">Fault / Complaint</p>
                <p className="text-sm text-gray-800">{job.fault}</p>
              </div>
            )}

            <div className="border-t border-dashed border-gray-200 pt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Estimate</span>
                <span className="font-bold text-gray-900">₹{Number(job.estimate).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Advance Paid</span>
                <span className="font-semibold text-green-600">₹{Number(job.advance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
              {balance > 0 && (
                <div className="flex justify-between text-base font-bold border-t pt-2 border-gray-200 mt-1">
                  <span className="text-gray-800">Balance Due</span>
                  <span className="text-red-600">₹{balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                </div>
              )}
            </div>

            <div className="mt-6 border-t border-dashed border-gray-200 pt-4">
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wide">For X Press Mobile Care</p>
                <p className="text-xs text-gray-400">Authorised Signature</p>
              </div>
              <div className="h-10 border-b border-gray-300 mb-1" />
              {job.technician_name && <p className="text-xs text-gray-500 text-right">{job.technician_name}</p>}
            </div>
          </div>

          <div className="bg-gray-50 border-t border-dashed border-gray-200 p-4">
            <p className="text-xs font-bold text-gray-600 mb-2">Terms & Conditions :</p>
            <ol className="text-xs text-gray-500 space-y-1 list-decimal list-inside">
              <li>Goods must be collected within one week from the entry, failing which the management will not be responsible for delivery.</li>
              <li>(Job Card) இது தொடந்தாலே கொண்டுவரமல் வந்தாலோ பொருள் கணிப்பாக கொடுக்கப்படமாட்டாது.</li>
              <li>சர்வீஸ் செய்த பொருட்களுக்கு உத்திரவாதம் கிடையாது மற்றும் பழைய பொருட்கள் திரும்பி தரப்படமாட்டாது.</li>
              <li>குறிப்பிட்ட Due Date - ல் பொருள் தர முடியவில்லையெனில் Due Date - ல் கொடுக்கதற்கு 1) Spare, 2) பொருளின் வேலையே காரணம், எனவே Due Date - ல் பொருள் கொடுக்க முடியாமல் போகலாம்.</li>
            </ol>
          </div>

          <div className="bg-green-700 text-center py-3">
            <p className="text-green-100 text-xs">செல்போனை திரும்பப் பெறும்போது செல்போன் திரும்பி தரப்படமாட்டாது</p>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden; }
          #receipt, #receipt * { visibility: visible; }
          #receipt { position: absolute; left: 0; top: 0; width: 100%; }
        }
      `}</style>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-gray-400 font-medium">{label}</p>
      <p className="font-semibold text-gray-800 text-sm">{value}</p>
    </div>
  );
}

function AccessoryItem({ label, value }: { label: string; value: boolean }) {
  return (
    <div>
      <p className="text-xs text-gray-500">{label}</p>
      <div className="flex items-center gap-1 mt-0.5">
        {value
          ? <><CheckCircle size={14} className="text-green-500" /><span className="text-sm font-semibold text-green-700">Yes</span></>
          : <><XCircle size={14} className="text-red-400" /><span className="text-sm font-semibold text-red-500">No</span></>
        }
      </div>
    </div>
  );
}
