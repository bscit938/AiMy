import { useEffect, useState } from 'react';
import { Smartphone, Clock, CheckCircle, TruckIcon, TrendingUp, Plus } from 'lucide-react';
import { supabase, JobCard } from '../lib/supabase';

interface Stats {
  total: number;
  pending: number;
  in_progress: number;
  completed: number;
  delivered: number;
  todayCount: number;
  totalEstimate: number;
}

interface DashboardProps {
  onNewJob: () => void;
  onViewAll: () => void;
}

export default function Dashboard({ onNewJob, onViewAll }: DashboardProps) {
  const [stats, setStats] = useState<Stats>({
    total: 0, pending: 0, in_progress: 0, completed: 0, delivered: 0, todayCount: 0, totalEstimate: 0
  });
  const [recentJobs, setRecentJobs] = useState<JobCard[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    setLoading(true);
    const today = new Date().toISOString().split('T')[0];

    const [allRes, recentRes] = await Promise.all([
      supabase.from('job_cards').select('status, estimate, date'),
      supabase.from('job_cards').select('*').order('created_at', { ascending: false }).limit(5)
    ]);

    if (allRes.data) {
      const s: Stats = { total: 0, pending: 0, in_progress: 0, completed: 0, delivered: 0, todayCount: 0, totalEstimate: 0 };
      allRes.data.forEach((j) => {
        s.total++;
        s[j.status as keyof Pick<Stats, 'pending' | 'in_progress' | 'completed' | 'delivered'>]++;
        s.totalEstimate += Number(j.estimate) || 0;
        if (j.date === today) s.todayCount++;
      });
      setStats(s);
    }
    if (recentRes.data) setRecentJobs(recentRes.data as JobCard[]);
    setLoading(false);
  }

  const statusConfig = {
    pending: { label: 'Pending', color: 'bg-amber-100 text-amber-700', dot: 'bg-amber-500' },
    in_progress: { label: 'In Progress', color: 'bg-blue-100 text-blue-700', dot: 'bg-blue-500' },
    completed: { label: 'Completed', color: 'bg-green-100 text-green-700', dot: 'bg-green-500' },
    delivered: { label: 'Delivered', color: 'bg-gray-100 text-gray-600', dot: 'bg-gray-400' },
  };

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-sm text-gray-500 mt-1">{new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
        <button
          onClick={onNewJob}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2.5 rounded-xl font-semibold text-sm shadow-sm transition-colors"
        >
          <Plus size={16} />
          New Job Card
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-2xl p-5 animate-pulse h-28 shadow-sm" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard icon={<Smartphone size={20} />} label="Today's Jobs" value={stats.todayCount} color="bg-green-50 text-green-600" />
          <StatCard icon={<Clock size={20} />} label="Pending" value={stats.pending} color="bg-amber-50 text-amber-600" />
          <StatCard icon={<CheckCircle size={20} />} label="Completed" value={stats.completed} color="bg-blue-50 text-blue-600" />
          <StatCard icon={<TrendingUp size={20} />} label="Total Revenue" value={`₹${stats.totalEstimate.toLocaleString('en-IN')}`} color="bg-teal-50 text-teal-600" />
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="bg-white rounded-2xl p-5 shadow-sm col-span-1">
          <h3 className="font-semibold text-gray-700 mb-4 text-sm uppercase tracking-wide">Status Overview</h3>
          <div className="space-y-3">
            {(['pending', 'in_progress', 'completed', 'delivered'] as const).map((s) => (
              <div key={s} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${statusConfig[s].dot}`} />
                  <span className="text-sm text-gray-600">{statusConfig[s].label}</span>
                </div>
                <span className="font-semibold text-gray-800">{stats[s]}</span>
              </div>
            ))}
            <div className="pt-2 border-t border-gray-100 flex justify-between">
              <span className="text-sm font-semibold text-gray-700">Total</span>
              <span className="font-bold text-gray-900">{stats.total}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-sm col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-700 text-sm uppercase tracking-wide">Recent Job Cards</h3>
            <button onClick={onViewAll} className="text-green-600 text-sm font-medium hover:underline">View all</button>
          </div>
          {recentJobs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-gray-400">
              <TruckIcon size={32} className="mb-2 opacity-30" />
              <p className="text-sm">No job cards yet</p>
            </div>
          ) : (
            <div className="space-y-2">
              {recentJobs.map((job) => (
                <div key={job.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div>
                    <span className="font-semibold text-gray-800 text-sm">#{job.job_no}</span>
                    <span className="mx-2 text-gray-300">|</span>
                    <span className="text-gray-600 text-sm">{job.brand} {job.model}</span>
                    <div className="text-xs text-gray-400 mt-0.5">{job.mobile_no}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusConfig[job.status]?.color}`}>
                      {statusConfig[job.status]?.label}
                    </span>
                    <span className="text-xs text-gray-500">₹{Number(job.estimate).toLocaleString('en-IN')}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: string | number; color: string }) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm">
      <div className={`inline-flex p-2 rounded-xl ${color} mb-3`}>{icon}</div>
      <div className="text-2xl font-bold text-gray-900">{value}</div>
      <div className="text-xs text-gray-500 mt-1 font-medium">{label}</div>
    </div>
  );
}
