import { useState } from 'react';
import { LayoutDashboard, FileText, Smartphone, Menu, X } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import JobCardForm from './pages/JobCardForm';
import JobCardList from './pages/JobCardList';
import Receipt from './pages/Receipt';
import JobCardView from './pages/JobCardView';
import { JobCard } from './lib/supabase';

type Screen =
  | { name: 'dashboard' }
  | { name: 'list' }
  | { name: 'new' }
  | { name: 'edit'; job: JobCard }
  | { name: 'receipt'; job: JobCard }
  | { name: 'view'; job: JobCard };

export default function App() {
  const [screen, setScreen] = useState<Screen>({ name: 'dashboard' });
  const [navOpen, setNavOpen] = useState(false);

  function goTo(s: Screen) {
    setScreen(s);
    setNavOpen(false);
  }

  if (screen.name === 'new') {
    return (
      <JobCardForm
        onBack={() => goTo({ name: 'list' })}
        onSaved={(job) => goTo({ name: 'receipt', job })}
      />
    );
  }
  if (screen.name === 'edit') {
    return (
      <JobCardForm
        editJob={screen.job}
        onBack={() => goTo({ name: 'view', job: screen.job })}
        onSaved={(job) => goTo({ name: 'view', job })}
      />
    );
  }
  if (screen.name === 'receipt') {
    return (
      <Receipt
        job={screen.job}
        onBack={() => goTo({ name: 'list' })}
      />
    );
  }
  if (screen.name === 'view') {
    return (
      <JobCardView
        job={screen.job}
        onBack={() => goTo({ name: 'list' })}
        onEdit={(job) => goTo({ name: 'edit', job })}
        onPrint={(job) => goTo({ name: 'receipt', job })}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      <aside className={`
        fixed inset-y-0 left-0 z-30 w-64 bg-white border-r border-gray-100 shadow-xl flex flex-col transform transition-transform duration-200
        ${navOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static md:shadow-none
      `}>
        <div className="p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-green-600 rounded-xl flex items-center justify-center shadow-sm">
              <Smartphone size={18} className="text-white" />
            </div>
            <div>
              <h1 className="font-black text-gray-900 text-base leading-tight">Mobile Care</h1>
              <p className="text-xs text-gray-400">Service Centre Billing</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          <NavItem
            icon={<LayoutDashboard size={18} />}
            label="Dashboard"
            active={screen.name === 'dashboard'}
            onClick={() => goTo({ name: 'dashboard' })}
          />
          <NavItem
            icon={<FileText size={18} />}
            label="Job Cards"
            active={screen.name === 'list'}
            onClick={() => goTo({ name: 'list' })}
          />
        </nav>

        <div className="p-4 border-t border-gray-100">
          <div className="bg-green-50 rounded-xl p-3 text-center">
            <p className="text-xs font-semibold text-green-700">NRT Complex, Palladam</p>
            <p className="text-xs text-green-600 mt-0.5">9095 007 007</p>
          </div>
        </div>
      </aside>

      {navOpen && (
        <div className="fixed inset-0 bg-black/40 z-20 md:hidden" onClick={() => setNavOpen(false)} />
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b border-gray-100 px-4 py-3 flex items-center md:hidden shadow-sm sticky top-0 z-10">
          <button onClick={() => setNavOpen(!navOpen)} className="p-1.5 rounded-lg hover:bg-gray-100 mr-3 transition-colors">
            {navOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-green-600 rounded-lg flex items-center justify-center">
              <Smartphone size={14} className="text-white" />
            </div>
            <span className="font-bold text-gray-900 text-sm">Mobile Care Billing</span>
          </div>
        </header>

        <main className="flex-1 overflow-auto">
          {screen.name === 'dashboard' && (
            <Dashboard
              onNewJob={() => goTo({ name: 'new' })}
              onViewAll={() => goTo({ name: 'list' })}
            />
          )}
          {screen.name === 'list' && (
            <JobCardList
              onNew={() => goTo({ name: 'new' })}
              onEdit={(job) => goTo({ name: 'edit', job })}
              onPrint={(job) => goTo({ name: 'receipt', job })}
              onView={(job) => goTo({ name: 'view', job })}
            />
          )}
        </main>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
        active ? 'bg-green-600 text-white shadow-sm' : 'text-gray-600 hover:bg-gray-100'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
